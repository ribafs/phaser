import { PixelTexture } from '@phaserjs/phaser/textures/types';
import { PICO8 } from '@phaserjs/phaser/textures/palettes';

export const floorTexture = PixelTexture({
    data: [
        '66666',
        '66666',
        '66666',
        '66666',
        '66666'
    ],
    pixelWidth: 12,
    pixelHeight: 12,
    palette: PICO8
});

export const wallTexture = PixelTexture({
    data: [
        '11111',
        '11111',
        '11111',
        '11111',
        '11111'
    ],
    pixelWidth: 12,
    pixelHeight: 12,
    palette: PICO8
});

export const goalTexture = PixelTexture({
    data: [
        '66666',
        '66866',
        '68886',
        '66866',
        '66666'
    ],
    pixelWidth: 12,
    pixelHeight: 12,
    palette: PICO8
});

export const playerTexture = PixelTexture({
    data: [
        '.CCC.',
        '.FFF.',
        'CC.CC',
        '.CCC.',
        '.C.C.'
    ],
    pixelWidth: 12,
    pixelHeight: 12,
    palette: PICO8
});

export const crateTexture = PixelTexture({
    data: [
        '55555',
        '54.45',
        '5...5',
        '54.45',
        '55555'
    ],
    pixelWidth: 12,
    pixelHeight: 12,
    palette: PICO8
});

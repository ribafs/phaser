## Phaser.Physics.Arcade.ArcadePhysics

In case of doubt, the [official source code](https://github.com/photonstorm/phaser) should be accessed.

### Introduction

### Example

### Public Functions

#### velocityFromAngle

Calculate the velocity with the angle (degrees) and the speed.

#### velocityFromRotation

Calculate the velocity with the rotation (radians) and the speed.

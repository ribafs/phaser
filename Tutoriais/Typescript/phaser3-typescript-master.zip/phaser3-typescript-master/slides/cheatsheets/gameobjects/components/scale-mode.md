## Phaser.Components.ScaleMode

In case of doubt, the [official source code](https://github.com/photonstorm/phaser) should be accessed.

### Public Functions

#### setScaleMode

Set the scale mode.

> Either Phaser.ScaleModes.LINEAR or Phaser.ScaleModes.NEAREST).

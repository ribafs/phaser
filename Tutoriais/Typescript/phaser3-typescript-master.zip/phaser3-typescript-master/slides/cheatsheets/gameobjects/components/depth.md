## Phaser.Components.Depth

In case of doubt, the [official source code](https://github.com/photonstorm/phaser) should be accessed.

### Public Functions

#### setDepth

Depth (= z-index) of the game object.
A game object with a higher depth value will render in front of one with a lower value.

## Phaser.Components.Alpha

In case of doubt, the [official source code](https://github.com/photonstorm/phaser) should be accessed.

### Public Functions

#### clearAlpha

Clear all alpha values.

#### setAlpha

Set alpha values. 0 = fully transparent, 1 = fully opaque.
If the game runs under WebGL you can optionally specify four different alpha values.

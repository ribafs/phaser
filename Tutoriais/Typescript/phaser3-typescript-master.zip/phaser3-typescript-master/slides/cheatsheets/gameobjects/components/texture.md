## Phaser.Components.Texture

In case of doubt, the [official source code](https://github.com/photonstorm/phaser) should be accessed.

### Public Functions

#### setTexture

Set texture and frame of the game object.

#### setFrame

Set the frame of the game object.

> Either a string or an index.

## Phaser.Components.Visible

In case of doubt, the [official source code](https://github.com/photonstorm/phaser) should be accessed.

### Public Functions

#### setVisible

Set the visibility.

> An invisible game object will skip rendering, but will still process update logic.

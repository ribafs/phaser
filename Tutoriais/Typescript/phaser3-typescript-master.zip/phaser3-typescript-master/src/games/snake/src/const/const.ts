export let CONST = {
  SCORE: 0,
  HIGHSCORE: 0,
  FIELD_SIZE: 8
};

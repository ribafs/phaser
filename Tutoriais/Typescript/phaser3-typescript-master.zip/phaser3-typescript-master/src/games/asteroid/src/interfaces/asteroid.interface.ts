export interface IAsteroidConstructor {
  scene: Phaser.Scene;
  size: number;
  options?: Phaser.Types.GameObjects.Graphics.Options;
}

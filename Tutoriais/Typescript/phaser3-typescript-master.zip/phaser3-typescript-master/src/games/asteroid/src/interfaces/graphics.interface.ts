export interface IGraphicsConstructor {
  scene: Phaser.Scene;
  options?: Phaser.Types.GameObjects.Graphics.Options;
}

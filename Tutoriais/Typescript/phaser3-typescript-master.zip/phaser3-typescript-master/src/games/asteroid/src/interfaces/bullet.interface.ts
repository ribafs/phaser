export interface IBulletConstructor {
  scene: Phaser.Scene;
  rotation: number;
  options?: Phaser.Types.GameObjects.Graphics.Options;
}

export interface IPortalDestination {
  x: number;
  y: number;
  dir: string;
}

export let CONST = {
  P1_SCORE: 0,
  P2_SCORE: 0,
  FIELD_SIZE: 8
};

export interface ICellConstructor {
  scene: Phaser.Scene;
  x: number;
  y: number;
}

export interface IStarSystemConstructor {
  scene: Phaser.Scene;
  x: number;
  y: number;
}

export class Config {
    static gameWidth: number = 800;

    static gameHeight: number = 480;
}
